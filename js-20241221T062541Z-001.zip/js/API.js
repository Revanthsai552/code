const TelegramBot = require('node-telegram-bot-api');

const request = require('request');

const token = '7928829866:AAFpWhnXVGYGZWW1vDV9FOV8JDbVrVNMI40';

const bot = new TelegramBot(token, { polling: true });

let waitingFor = {};

let p;

bot.on('message',function (msg) {
    const chatId = msg.chat.id;
    const Input = msg.text.replaceAll(" ", "").toLowerCase();
    console.log(msg);

    if(Input === '/start'){
        bot.sendMessage(chatId,"Hi "+msg.from.first_name+" i'm a Poke Bot. \nselect data you want .", {
            reply_markup: {
                inline_keyboard: [
                    [{ text: 'Pokemon data', callback_data: 'poke' }],
                    [{ text: 'Moves data', callback_data: 'mv' }],
                    [{ text: 'Items data', callback_data: 'it' }],
                    [{ text: 'Cancel', callback_data: 'CC' }]
                ]
            }
        });
    }
    else if (waitingFor[chatId]){
        handleOption(chatId,Input);
    }
    else if(Input === '/cancel'){
        delete waitingFor[chatId];
        bot.sendMessage(chatId, "option has been canceled.\nplease enter /start for options.");
    }
    else {
        bot.sendMessage(chatId, "Sorry, I can't understand you.\nPlease send /start to select options.");
    }
});


bot.on('callback_query',function (query){
    const chatId = query.message.chat.id;
    const data = query.data;
    switch(data){
        case 'poke':
            waitingFor[chatId] = 'poke';
            bot.sendMessage(chatId,"Enter a Pokemon name or it's dex entry number :")
            break;
        case 'mv':
            waitingFor[chatId] = 'mv';
            bot.sendMessage(chatId, "Enter a Move name or it's ID :");
            break;
        case 'it':
            waitingFor[chatId] = 'it';
            bot.sendMessage(chatId, "Enter a Item name or it's ID :");
            break;
        case 'pokepic':
            waitingFor[chatId] = 'pokepic';
            handleOption(chatId,p)
            break;
        case 'pmv':
            waitingFor[chatId] = 'pmv';
            handleOption(chatId,p)
            break;
        case 'pst':
            waitingFor[chatId] = 'pst';
            handleOption(chatId,p)
            break;
        case 'pty':
            waitingFor[chatId] = 'pty';
            handleOption(chatId,p)
            break;
        case 'pab':
            waitingFor[chatId] = 'pab';
            handleOption(chatId,p)
            break;
        case 'Mvl':
            waitingFor[chatId] = 'Mvl';
            handleOption(chatId,p)
            break;
        case 'Mvd':
            waitingFor[chatId] = 'Mvd';
            handleOption(chatId,p)
            break;    
        case 'CC':
            delete waitingFor[chatId];
            bot.sendMessage(chatId, "option has been canceled.\nplease enter /start for options.");
            break;

    }
});

function handleOption(chatId,input) {
    const task = waitingFor[chatId]; 
    p = input;
    switch(task){
        case 'poke':                 
            bot.sendMessage(chatId,"Select data you want ",{
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Pokemon dex picture', callback_data: 'pokepic' }],
                        [{ text: 'All Moves of pokemon', callback_data: 'pmv' }],
                        [{ text: 'Base stats', callback_data: 'pst' }],
                        [{ text: 'Pokemon type', callback_data: 'pty' }],
                        [{ text: 'Pokemon ability', callback_data: 'pab' }],
                        [{ text: 'Cancel', callback_data: 'CC' }]
                    ]
                }
            })              
            break;
        case 'mv':
            bot.sendMessage(chatId,"Select data you want .", {
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Can be Learned by', callback_data: 'Mvl' }],
                        [{ text: 'Move Data', callback_data: 'Mvd' }],
                        [{ text: 'Cancel', callback_data: 'CC' }]
                    ]
                }
            })
            break;
        case 'it':
            request('https://pokeapi.co/api/v2/item/'+input+'/', function (error, response, body) {
                if(body  != 'Not Found'){
                    let data = JSON.parse(body)
                    bot.sendMessage(chatId,data.name+"\ncost : "+data.cost+"\ndescription : "+data.effect_entries[0].short_effect);
                }else{
                    bot.sendMessage(chatId, 'Sorry, '+input+" is not a valid item number or name .\ncheck for spelling mistakes And Please try again.\nNote:- if there is a space in the word replace it with - ");
                }
            });
            break;
        case 'pokepic':
            request('https://pokeapi.co/api/v2/pokemon/'+input+'/', function (error, response, body) {
                if(body  != 'Not Found'){
                    let data = JSON.parse(body)
                    bot.sendMessage(chatId,data.name);
                    bot.sendPhoto(chatId,data.sprites.front_default)
                    bot.sendMessage(chatId,"Shiny "+data.name);
                    bot.sendPhoto(chatId,data.sprites.front_shiny)
                }else{
                    bot.sendMessage(chatId, 'Sorry, '+input+" is not a valid dex number or Pokemon name .\ncheck for spelling mistakes And Please try again.\nNote:- if there is a space in the word replace it with - ");
                }  
            })
            break;
        case 'pmv':
            request('https://pokeapi.co/api/v2/pokemon/'+input+'/', function (error, response, body) {
                if(body  != 'Not Found'){
                    let data = JSON.parse(body)
                    data.moves.forEach(ele => {
                        bot.sendMessage(chatId,ele.move.name)
                    });
                }else{
                    bot.sendMessage(chatId, 'Sorry, '+input+" is not a valid dex number or Pokemon name .\ncheck for spelling mistakes And Please try again.\nNote:- if there is a space in the word replace it with - ");
                }
            })
            break;
        case 'pab':
            request('https://pokeapi.co/api/v2/pokemon/'+input+'/', function (error, response, body) {
                if(body  != 'Not Found'){
                    let data = JSON.parse(body)
                    bot.sendMessage(data.name)
                    data.abilities.forEach((i,j) => {
                        bot.sendMessage(chatId,(j+1)+" "+i.ability.name)
	                })
                }else{
                    bot.sendMessage(chatId, 'Sorry, '+input+" is not a valid dex number or Pokemon name .\ncheck for spelling mistakes And Please try again.\nNote:- if there is a space in the word replace it with - ");
                }
            })
            break;

        case 'pst':
            request('https://pokeapi.co/api/v2/pokemon/'+input+'/', function (error, response, body) {
                if(body  != 'Not Found'){
                    let data = JSON.parse(body)
                    bot.sendMessage(chatId,"Base stats of "+data.name)
                    data.stats.forEach(ele=> {
                        bot.sendMessage(chatId,ele.stat.name+" : "+ele.base_stat)
                    });
                }else{
                    bot.sendMessage(chatId, 'Sorry, '+input+" is not a valid dex number or Pokemon name .\ncheck for spelling mistakes And Please try again.\nNote:- if there is a space in the word replace it with - ");
                }
            })
            break;

        case 'pty':
            request('https://pokeapi.co/api/v2/pokemon/'+input+'/', function (error, response, body) {
                if(body  != 'Not Found'){
                    let data = JSON.parse(body)
                    bot.sendMessage(chatId,data.name)
                    data.types.forEach(ele=> {
                        bot.sendMessage(chatId,ele.type.name)
                    });
                }else{
                    bot.sendMessage(chatId, 'Sorry, '+input+" is not a valid dex number or Pokemon name .\ncheck for spelling mistakes And Please try again.\nNote:- if there is a space in the word replace it with - ");
                }
            })
            break;
        case 'Mvd':
            request('https://pokeapi.co/api/v2/move/'+input+'/', function (error, response, body) {
                if(body  != 'Not Found'){
                    let data = JSON.parse(body)
                    bot.sendMessage(chatId,data.name+" stats :-\npower : "+data.power+"\naccuracy : "+data.accuracy+"\npp : "+data.pp+"\npriority : "+data.priority+"\ntype : "+data.type.name+"\ndescription : "+data.effect_entries[0].short_effect);
                }else{
                    bot.sendMessage(chatId, 'Sorry, '+input+" is not a valid move number or Move name .\ncheck for spelling mistakes And Please try again.\nNote:- if there is a space in the word replace it with - ");
                }
            });
            break;
        case 'Mvl':
            request('https://pokeapi.co/api/v2/move/'+input+'/', function (error, response, body) {
                if(body  != 'Not Found'){
                    let data = JSON.parse(body)
                    bot.sendMessage(chatId,data.name+' can be learned by :- ');
                    data.learned_by_pokemon.forEach(ele => {
                        bot.sendMessage(chatId,ele.name)
                    });
                }else{
                    bot.sendMessage(chatId, 'Sorry, '+input+" is not a valid move number or Move name .\ncheck for spelling mistakes And Please try again.\nNote:- if there is a space in the word replace it with - ");
                }
            }); 
    }
}