const TelegramBot = require('node-telegram-bot-api');

const token = '7269792483:AAH5N6HVpQwEG_5hm1jXPL3aWci8IPAWyYo';

const bot = new TelegramBot(token, { polling: true });

let waitingFor = {}; 

bot.on('message',function (msg) {
    const chatId = msg.chat.id;
    const Input = msg.text;
    console.log(msg)
    if (Input === '/start') {
        bot.sendMessage(chatId, 'Hello '+msg.from.first_name+"\nI'm Jarvis.", {
            reply_markup: {
                inline_keyboard: [
                    [{ text: 'Positive/Negative', callback_data: 'p_n' }],
                    [{ text: 'Odd/Even', callback_data: 'o_e' }]
                ]
            }
        });
    } else if (waitingFor[chatId]) {
        handleNumber(chatId,Input);
    } else {
        bot.sendMessage(chatId, "Sorry, I can't understand you.\nPlease send /start to select options.");
    }
});

bot.on('callback_query',function (query){
    const chatId = query.message.chat.id;
    const data = query.data;
    console.log(query)
    if (data === 'p_n') {
        bot.sendMessage(chatId, "Enter a number to check if it's Positive or Negative:");
        waitingFor[chatId] = 'p_n';
    } else if (data === 'o_e') {
        bot.sendMessage(chatId, "Enter a number to check if it's Odd or Even:");
        waitingFor[chatId] = 'o_e';
    }
});

function handleNumber(chatId, input) {
    const task = waitingFor[chatId];
    const num = Number(input);

    if (isNaN(num)) {
        // Validate if the input is a number
        bot.sendMessage(chatId, 'Sorry, '+input+' is not a valid number. Please try again.');
        return;
    }

    if (task === 'p_n') {
        // Check if the number is Positive, Negative, or Zero
        if (num === 0) {
            bot.sendMessage(chatId, num +' is Zero.');
        } else if (num > 0) {
            bot.sendMessage(chatId, num+' is a Positive number.' );
        } else {
            bot.sendMessage(chatId, num+' is a Negative number.' );
        }
    } else if (task === 'o_e') {
        // Check if the number is Odd or Even
        if (num % 2 === 0) {
            bot.sendMessage(chatId, num+' is an Even number.');
        } else {
            bot.sendMessage(chatId, num+' is an Odd number.');
        }
    }
    delete waitingFor[chatId];
}
