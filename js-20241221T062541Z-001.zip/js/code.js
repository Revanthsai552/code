const TelegramBot = require('node-telegram-bot-api');

const token = '7935465809:AAGHJkK3NDdUVpWxTekuqcZYXPPxSYirukA'

const bot = new TelegramBot(token, { polling: true });

bot.on('message',function (msg) {
    const chatId = msg.chat.id;
    const Input = msg.text;
    const num = Number(Input);
    console.log(msg)
    if (!isNaN(num)) {
        if(num % 2 == 0){
            bot.sendMessage(chatId, num+" is an even number.");
        }else{
            bot.sendMessage(chatId, num+" is an odd number.");
        }
    }else{
        bot.sendMessage(chatId, Input+" is not a number ");
    }
})
